#!bin/bash

rm -rf mis-carpetas-examen
mkdir mis-carpetas-examen

INPUT_STRING=0
array=()

while [ "$INPUT_STRING" != "1000" ]
do
 echo "Ingrese un numero"
 read INPUT_STRING
 if [ $(($INPUT_STRING%2)) -eq 0 ]
 then
  FName=$(($INPUT_STRING*3))
  mkdir "mis-carpetas-examen/$FName"
  if [ "$INPUT_STRING" -gt "20" ]
  then
   array+=($INPUT_STRING)
   echo "$INPUT_STRING saved in array"
  fi
 else
  FName=$(($INPUT_STRING*5))
  mkdir "mis-carpetas-examen/$FName"
 fi
  echo "Folder $FName created"
done

for num in "${array[@]}"
do
 echo "El numero guardado es $num"
done

#Set permits
chmod u=rwx "mis-carpetas-examen"
chmod g=rx "mis-carpetas-examen"
chmod o= "mis-carpetas-examen"

